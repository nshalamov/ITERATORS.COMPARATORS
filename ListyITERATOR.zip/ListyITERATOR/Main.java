package ListyITERATOR;

import java.util.Arrays;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);

        String[] create = Arrays
                .stream(scan.nextLine().split("\\s+"))
                .skip(1)
                .toArray(String[]::new);

        ListyIterator<String> list = new ListyIterator<>(create);

        String input = scan.nextLine();
        while (!input.equals("END")) {
            switch (input) {
                case "Move":
                    System.out.println(list.move());
                    break;
                case "HasNext":
                    System.out.println(list.hasNext());
                    break;
                case "Print":
                    try {
                        System.out.println(list.getCurrent());
                    } catch (UnsupportedOperationException ex) {
                        System.out.println(ex.getMessage());
                    }
                    break;
            }
            input = scan.nextLine();
        }
    }
}