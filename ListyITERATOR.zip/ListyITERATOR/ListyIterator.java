package ListyITERATOR;

import java.util.Arrays;
import java.util.List;

public class ListyIterator<String> {
    private final List<String> elements;
    private int indexPosition;

    public ListyIterator(String... elements) {
        this.elements = Arrays.asList(elements);
        this.indexPosition = 0;
    }

    public boolean move() {
        if(this.indexPosition == this.elements.size() - 1) {
            return false;
        }

        this.indexPosition++;
        return true;
    }

    public boolean hasNext() {
        return this.indexPosition < this.elements.size() - 1;
    }

    public String getCurrent() {
        if (this.elements.size() == 0) {
            throw new UnsupportedOperationException("Invalid Operation!");
        }

        return this.elements.get(this.indexPosition);
    }
}