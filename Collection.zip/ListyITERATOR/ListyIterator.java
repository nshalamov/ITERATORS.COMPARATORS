package ListyITERATOR;

import java.util.Arrays;
import java.util.Iterator;
import java.util.List;


public class ListyIterator<String> implements Iterable<String> {
    private final List<String> elements;
    private int indexPosition;

    public ListyIterator(String... elements) {
        this.elements = Arrays.asList(elements);
        this.indexPosition = 0;
    }

    public boolean move() {
        if(this.indexPosition == this.elements.size() - 1) {
            return false;
        }

        this.indexPosition++;
        return true;
    }

    public boolean hasNext() {
        return this.indexPosition < this.elements.size() - 1;
    }

    public String getCurrent() {
        if (this.elements.size() == 0) {
            throw new UnsupportedOperationException("Invalid Operation!");
        }

        return this.elements.get(this.indexPosition);
    }

    private class iter implements Iterator<String> {
        int index = 0;

        @Override
        public boolean hasNext() {
            return index < elements.size();
        }

        @Override
        public String next() {
            return elements.get(index++);
        }
    }

    @Override
    public Iterator<String> iterator() {
        return new iter();
    }

}